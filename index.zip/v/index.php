<?php
/* =====================
   INIT & SECURITY
===================== */
$id = isset($_GET['id'])
  ? preg_replace('/[^A-Za-z0-9._-]/', '', $_GET['id'])
  : '';

$year = date('Y');

/* =====================
   INCLUDE HELPER
===================== */
function include_to_var(string $path): string {
  if (!file_exists($path)) return '';
  ob_start();
  include $path;
  return trim(ob_get_clean());
}

/* =====================
   ADS / EXTERNAL
===================== */
$popunder      = include_to_var(__DIR__ . '/../popunder.php');
$native_banner = include_to_var(__DIR__ . '/../native_banner.php');
$socialbar     = include_to_var(__DIR__ . '/../socialbar.php');
$histats       = include_to_var(__DIR__ . '/../histats.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Watch on Videy</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="https://videy.co/favicon.ico">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<style>
/* ===== RESET ===== */
*{box-sizing:border-box}
html,body{height:100%}

/* ===== BODY & LAYOUT ===== */
body{
  margin:0;
  font-family:'Inter',Arial,sans-serif;
  background:#fff;
  color:#111;
  display:flex;
  flex-direction:column;
  min-height:100vh;
}

/* ===== HEADER ===== */
.main-header{
  width:100%;
  border-bottom:1px solid #e5e7eb;
  background:#fff;
}
.header-container{
  max-width:1100px;
  margin:auto;
  padding:12px 16px;
  display:flex;
  gap:14px;
  align-items:center;
}
.header-title{
  font-size:26px;
  font-weight:700;
}
.header-upload{
  text-decoration:none;
  background:#f3f4f6;
  padding:8px 16px;
  border-radius:16px;
  color:#111;
  font-weight:600;
}

/* ===== MAIN CONTENT ===== */
.page-content{
  flex:1;
  width:100%;
  display:flex;
  flex-direction:column;
  align-items:center;
}

/* ===== VIDEO ===== */
.video-player-wrap{
  width:100%;
  padding:20px 0;
  display:flex;
  justify-content:center;
}
.video-box{
  width:800px;
  max-width:95vw;
  aspect-ratio:16/9;
  background:#000;
  border-radius:16px;
  overflow:hidden;
  box-shadow:0 2px 16px rgba(0,0,0,.08);
}
video{
  width:100%;
  height:100%;
  object-fit:contain;
  background:#000;
}

/* ===== ADS ===== */
.video-actions{
  margin-top:16px;
  text-align:center;
}
.native-banner-wrap{
  margin:24px 0;
}

/* ===== FOOTER ===== */
footer{
  text-align:center;
  padding:20px 10px;
  font-size:13px;
  color:#777;
}

/* ===== MOBILE ===== */
@media(max-width:768px){
  .video-box{border-radius:8px}
  .header-title{font-size:22px}
}
</style>

<?= $popunder ?>
</head>

<body>

<!-- ===== HEADER ===== -->
<header class="main-header">
  <div class="header-container">
    <div class="header-title">Videy</div>
    <a href="/" class="header-upload">Upload</a>
  </div>
</header>

<!-- ===== MAIN ===== -->
<div class="page-content">

  <div class="video-player-wrap">
    <div class="video-box">
      <video id="video"
        controls
        playsinline
        controlsList="nodownload noplaybackrate"
        oncontextmenu="return false;">
      </video>
    </div>
  </div>

  <div class="video-actions">
    
  </div>

  <div class="native-banner-wrap">
    <?= $native_banner ?>
  </div>

</div>

<!-- ===== FOOTER ===== -->
<footer>
  © <?= $year ?> Videy<br>
  <a href="#">Terms of Service</a> • <a href="#">Report Abuse</a>
</footer>

<!-- ===== VIDEO SCRIPT ===== -->
<script>
const video = document.getElementById('video');
const id = <?= json_encode($id) ?>;
const base = 'https://cdn.videy.co/' + id;

function loadVideo(src){
  video.src = src;
  video.load();
}

if(id){
  loadVideo(base + '.mp4');
}

video.onerror = () => {
  if(!video.dataset.mov){
    video.dataset.mov = 1;
    loadVideo(base + '.mov');
  }
};
</script>

<?= $socialbar ?>
<?= $histats ?>

</body>
</html>
